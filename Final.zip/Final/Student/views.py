from django.shortcuts import render
from django.http import HttpResponse
from Student.models import Studentdetails
from Student.models import Coursedetails
from Student.models import Enrollment
from django.db import connection
from django.db.models import Avg
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
# Create your views here.
def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]

@login_required
def home(request):
    countstudents = Studentdetails.objects.all().count()
    countcourses = Coursedetails.objects.all().count() 
    avg= list(Studentdetails.objects.all().aggregate(Avg('gpa')).values())[0]
    countsophomore=Studentdetails.objects.filter(year='Sophomore').count()
    countjunior=Studentdetails.objects.filter(year='Junior').count()
    countsenior=Studentdetails.objects.filter(year='Senior').count()
    print(countstudents)
    print(countcourses)
    print(avg)
    print(countsophomore)
    print(countjunior)
    print(countsenior)
    return render(request, 'Student/home.html',{'data':countstudents,'courses':countcourses,'gpa':avg, 'sophomore':countsophomore, 'junior':countjunior, 'senior':countsenior})
    
    
@login_required 
def studentdetails(request):
    student=Studentdetails.objects.all()
    print(student)
    paginator= Paginator(student,10)
    page = request.GET.get('page')
    studentdata = paginator.get_page(page)
    return render(request, 'Student/studentdetails.html', {'data':studentdata})
@login_required
def coursedetails(request):
    course=Coursedetails.objects.all()
    print(course)
    paginator= Paginator(course,10)
    page = request.GET.get('page')
    coursedata = paginator.get_page(page)
    return render(request,'Student/coursedetails.html', {'data':coursedata})
    
@login_required
def enrollment(request):
    student= Studentdetails.objects.all()
    coursedata=Coursedetails.objects.all()
    enrollmentdata=Enrollment.objects.all()
    if('lastname' in request.session):
        enrollmentdata=Enrollment.objects.filter(lastname=request.session['lastname'])
    if('lname' in request.GET and 'cname' not in request.GET):
        lname=request.GET.get ('lname')
        request.session['lastname']= lname
        return HttpResponse('Success')
    if('lname' in request.GET and 'cname' in request.GET):
        lname=request.GET.get('lname')
        cname=request.GET.get('cname')
        courseinfo=Coursedetails.objects.filter(coursename=cname)
        enrollcourseid = courseinfo.values()[0]['courseid']
        enrollsectioncode = courseinfo.values()[0]['coursesectioncode']
        enrollmentdata=Enrollment.objects.filter(lastname=lname)
        for row in enrollmentdata:
            if row.coursename==cname:
                return HttpResponse('Error')
        newdata= Enrollment(lastname=lname,coursename=cname, courseid=enrollcourseid, coursesectioncode=enrollsectioncode)
        newdata.save()
        return HttpResponse('Success')
    return render(request, 'Student/enrollment.html', {'student':student,'course':coursedata,'enrollment':enrollmentdata})